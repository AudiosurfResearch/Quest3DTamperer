#pragma once

class A3d_Channel;
class A3d_ChannelGroup;

#include <string>

class ChannelGroupWrapper
{
public:

	explicit ChannelGroupWrapper(A3d_ChannelGroup* group);

	A3d_Channel* getChannel(int index);
	std::string getPoolName();

private:

	A3d_ChannelGroup* m_ChannelGroup;

};