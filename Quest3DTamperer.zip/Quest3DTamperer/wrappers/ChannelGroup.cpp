#include "../pch.h"
#include "ChannelGroup.h"

#include <A3d_List.h>
#include <A3d_Channels.h>
#include <A3d_ChannelGroup.h>
#include <A3d_EngineInterface.h>
#include <Aco_String.h>

ChannelGroupWrapper::ChannelGroupWrapper(A3d_ChannelGroup* group) : m_ChannelGroup(group) {}

A3d_Channel* ChannelGroupWrapper::getChannel(int index)
{
	if (m_ChannelGroup->channelsList_.GetItemCount() > index)
		return reinterpret_cast<A3d_Channel*>(m_ChannelGroup->channelsList_.GetItem(index));
	else
		return nullptr;
}

std::string ChannelGroupWrapper::getPoolName()
{
	struct Offset
	{
		char buffer[4];
		const char* str;
	}*offset;

	offset = reinterpret_cast<Offset*>(m_ChannelGroup->poolGroupName_);

	return std::string(offset->str);
}